﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Management_System
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }
        Branch_info bi;
        private void branchInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if (bi == null)
            {
                bi = new Branch_info();
                bi.MdiParent = this;
                bi.FormClosed += Bi_FormClosed;
                bi.Show();
            }
            else
                bi.Activate();


        }

        private void Bi_FormClosed(object sender, FormClosedEventArgs e)
        {
            bi = null;
           /// throw new NotImplementedException();
        }


        Department D;
        private void departmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            if (D == null)
            {
                D = new Department();
                D.MdiParent = this;
                D.FormClosed += D_FormClosed;
                D.Show();
            }
            else
                D.Activate();
        }

        private void D_FormClosed(object sender, FormClosedEventArgs e)
        {
            D = null;
           // throw new NotImplementedException();
        }

        Department_info di;
        private void departmentInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            if (di == null)
            {
                di = new Department_info();
                di.MdiParent = this;
                di.FormClosed += Di_FormClosed;
                di.Show();
            }
            else
                di.Activate();
        }

        private void Di_FormClosed(object sender, FormClosedEventArgs e)
        {
            di = null;
           // throw new NotImplementedException();
        }

        Department_manager dm;
        private void departmentManagerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if (dm == null)
            {
                dm = new Department_manager();
                dm.MdiParent = this;
                dm.FormClosed += Dm_FormClosed;
                dm.Show();
            }
            else

                dm.Activate();
        }

        private void Dm_FormClosed(object sender, FormClosedEventArgs e)
        {

            dm = null;
            //throw new NotImplementedException();
        }

        Employee_info ei;
        private void employeeInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            if (ei == null)
            {
                ei = new Employee_info();
                ei.MdiParent = this;
                ei.FormClosed += Ei_FormClosed;
                ei.Show();
            }
            else
                ei.Activate();
        }

        private void Ei_FormClosed(object sender, FormClosedEventArgs e)
        {
            ei = null;
            //throw new NotImplementedException();
        }

        Job_title jt;
        private void jobTitleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (jt == null)
            {
                jt = new Job_title();
                jt.MdiParent = this;
                jt.FormClosed += Jt_FormClosed;
                jt.Show();
            }
            else
                jt.Activate();
        }

        private void Jt_FormClosed(object sender, FormClosedEventArgs e)
        {
            jt = null;
            //throw new NotImplementedException();
        }
        Salary S;
        private void salaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (S == null)
            {
                S = new Salary();
                S.MdiParent = this;
                S.FormClosed += S_FormClosed;
                S.Show();
            }
            else
                S.Activate();
        }

        private void S_FormClosed(object sender, FormClosedEventArgs e)
        {
            S = null;
           // throw new NotImplementedException();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show("Please confirm if you want to exit", "HR Management System",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void HR_Main_Page_Load(object sender, EventArgs e)
        {

        }

        private void main_Load(object sender, EventArgs e)
        {

        }
    }
    }

