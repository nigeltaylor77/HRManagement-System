﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Management_System
{
    public partial class Branch_info : Form
    {
        public Branch_info()
        {
            InitializeComponent();
        }

        private void branch_infoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.branch_infoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.emp_Data);

        }

        private void Branch_info_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'emp_Data.Branch_info' table. You can move, or remove it, as needed.
            this.branch_infoTableAdapter.Fill(this.emp_Data.Branch_info);

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            
            this.Validate();
            this.branch_infoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.emp_Data);
            MessageBox.Show("Record Saved");
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {



            this.branch_infoBindingSource.AddNew();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DialogResult iDelete;

            iDelete = MessageBox.Show("Please confirm if you want to delete", "Employee Info",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iDelete == DialogResult.Yes)
                MessageBox.Show("Record Deleted");
            this.Validate();
            this.branch_infoBindingSource.RemoveCurrent();
            this.tableAdapterManager.UpdateAll(this.emp_Data);
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            emp_idTextBox.Clear();
            
            
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            DialogResult iClose;

            iClose = MessageBox.Show("Please confirm if you want to close", "Branch Info",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iClose == DialogResult.Yes)
            {
                this.Hide();
            }
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            this.branch_infoBindingSource.MoveNext();
        }

        private void btn_Previous_Click(object sender, EventArgs e)
        {
            this.branch_infoBindingSource.MovePrevious();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show("Please confirm if you want to exit", "Branch Info",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.branch_infoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.emp_Data);
            MessageBox.Show("Record Updated");
        }
    }
}
