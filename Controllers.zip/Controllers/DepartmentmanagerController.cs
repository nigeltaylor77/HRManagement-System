﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1hrsystem.Models;

namespace WebApplication1hrsystem.Controllers
{
    public class DepartmentmanagerController : Controller
    {
        private EmpDatabaseEntities1 db = new EmpDatabaseEntities1();

        // GET: Departmentmanager
        public ActionResult Index()
        {
            return View(db.Department_manager.ToList());
        }

        // GET: Departmentmanager/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department_manager department_manager = db.Department_manager.Find(id);
            if (department_manager == null)
            {
                return HttpNotFound();
            }
            return View(department_manager);
        }

        // GET: Departmentmanager/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Departmentmanager/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Emp_id,Dept_id,From_date,To_date")] Department_manager department_manager)
        {
            if (ModelState.IsValid)
            {
                db.Department_manager.Add(department_manager);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(department_manager);
        }

        // GET: Departmentmanager/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department_manager department_manager = db.Department_manager.Find(id);
            if (department_manager == null)
            {
                return HttpNotFound();
            }
            return View(department_manager);
        }

        // POST: Departmentmanager/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Emp_id,Dept_id,From_date,To_date")] Department_manager department_manager)
        {
            if (ModelState.IsValid)
            {
                db.Entry(department_manager).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(department_manager);
        }

        // GET: Departmentmanager/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department_manager department_manager = db.Department_manager.Find(id);
            if (department_manager == null)
            {
                return HttpNotFound();
            }
            return View(department_manager);
        }

        // POST: Departmentmanager/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Department_manager department_manager = db.Department_manager.Find(id);
            db.Department_manager.Remove(department_manager);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
