﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1hrsystem.Models;

namespace WebApplication1hrsystem.Controllers
{
    public class JobtitlesController : Controller
    {
        private EmpDatabaseEntities1 db = new EmpDatabaseEntities1();

        // GET: Jobtitles
        public ActionResult Index()
        {
            return View(db.Job_titles.ToList());
        }

        // GET: Jobtitles/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Job_titles job_titles = db.Job_titles.Find(id);
            if (job_titles == null)
            {
                return HttpNotFound();
            }
            return View(job_titles);
        }

        // GET: Jobtitles/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Jobtitles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Emp_id,Job_title,From_date,To_date")] Job_titles job_titles)
        {
            if (ModelState.IsValid)
            {
                db.Job_titles.Add(job_titles);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(job_titles);
        }

        // GET: Jobtitles/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Job_titles job_titles = db.Job_titles.Find(id);
            if (job_titles == null)
            {
                return HttpNotFound();
            }
            return View(job_titles);
        }

        // POST: Jobtitles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Emp_id,Job_title,From_date,To_date")] Job_titles job_titles)
        {
            if (ModelState.IsValid)
            {
                db.Entry(job_titles).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(job_titles);
        }

        // GET: Jobtitles/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Job_titles job_titles = db.Job_titles.Find(id);
            if (job_titles == null)
            {
                return HttpNotFound();
            }
            return View(job_titles);
        }

        // POST: Jobtitles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Job_titles job_titles = db.Job_titles.Find(id);
            db.Job_titles.Remove(job_titles);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
