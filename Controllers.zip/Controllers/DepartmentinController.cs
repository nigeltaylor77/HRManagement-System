﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1hrsystem.Models;

namespace WebApplication1hrsystem.Controllers
{
    public class DepartmentinController : Controller
    {
        private EmpDatabaseEntities1 db = new EmpDatabaseEntities1();

        // GET: Departmentin
        public ActionResult Index()
        {
            return View(db.Department_info.ToList());
        }

        // GET: Departmentin/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department_info department_info = db.Department_info.Find(id);
            if (department_info == null)
            {
                return HttpNotFound();
            }
            return View(department_info);
        }

        // GET: Departmentin/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Departmentin/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Emp_id,Dept_id,From_date,To_date")] Department_info department_info)
        {
            if (ModelState.IsValid)
            {
                db.Department_info.Add(department_info);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(department_info);
        }

        // GET: Departmentin/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department_info department_info = db.Department_info.Find(id);
            if (department_info == null)
            {
                return HttpNotFound();
            }
            return View(department_info);
        }

        // POST: Departmentin/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Emp_id,Dept_id,From_date,To_date")] Department_info department_info)
        {
            if (ModelState.IsValid)
            {
                db.Entry(department_info).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(department_info);
        }

        // GET: Departmentin/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Department_info department_info = db.Department_info.Find(id);
            if (department_info == null)
            {
                return HttpNotFound();
            }
            return View(department_info);
        }

        // POST: Departmentin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Department_info department_info = db.Department_info.Find(id);
            db.Department_info.Remove(department_info);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
