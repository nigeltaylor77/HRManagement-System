﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1hrsystem.Models;

namespace WebApplication1hrsystem.Controllers
{
    public class EmployeeinfoController : Controller
    {
        private EmpDatabaseEntities1 db = new EmpDatabaseEntities1();

        // GET: Employeeinfo
        public ActionResult Index()
        {
            return View(db.Employee_info.ToList());
        }

        // GET: Employeeinfo/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_info employee_info = db.Employee_info.Find(id);
            if (employee_info == null)
            {
                return HttpNotFound();
            }
            return View(employee_info);
        }

        // GET: Employeeinfo/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employeeinfo/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Emp_id,Personal_id,First_name,Last_name,DOB,Gender,Hired_date,End_date,Address,Phone_,Email,Country")] Employee_info employee_info)
        {
            if (ModelState.IsValid)
            {
                db.Employee_info.Add(employee_info);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee_info);
        }

        // GET: Employeeinfo/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_info employee_info = db.Employee_info.Find(id);
            if (employee_info == null)
            {
                return HttpNotFound();
            }
            return View(employee_info);
        }

        // POST: Employeeinfo/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Emp_id,Personal_id,First_name,Last_name,DOB,Gender,Hired_date,End_date,Address,Phone_,Email,Country")] Employee_info employee_info)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_info).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee_info);
        }

        // GET: Employeeinfo/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_info employee_info = db.Employee_info.Find(id);
            if (employee_info == null)
            {
                return HttpNotFound();
            }
            return View(employee_info);
        }

        // POST: Employeeinfo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_info employee_info = db.Employee_info.Find(id);
            db.Employee_info.Remove(employee_info);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
